module.exports = {
    home: '',
    links: [
        {
            hash: 'philosophy',
            text: 'Философия'
        },
        {
            hash: 'history',
            text: 'История'
        },
        {
            hash: 'achievements',
            text: 'Достижения'
        },
        {
            hash: 'collections',
            text: 'Коллекции'
        }
    ]
};
