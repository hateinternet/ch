module.exports = {
    legal: '',
    socials: [
        {
            name: 'instagram',
            href: ''
        },
        {
            name: 'facebook',
            href: ''
        },
        {
            name: 'youtube',
            href: ''
        }
    ]
};
